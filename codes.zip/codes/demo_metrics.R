# This file compute the three metrics used in the paper.
# The file *.txt contains the optimized annotation matrix and is computed by the matlab file.
# alpha is the threshold.

source('Simulate_complete.r')
# output_emvc<-Simulate_complete(EMVC=TRUE)
output_rtmtl<-Simulate_complete(file = "out_simulated_0_20_10.txt",alpha=0.15, EMVC=FALSE) 

auc <- output_rtmtl$auc
fdr <- output_rtmtl$fdr
KC <- output_rtmtl$kc

source('Msigdbc2_complete.r')
#output_emvc<-Msigdbc2_complete(EMVC=TRUE)
output_rtmtl<-Msigdbc2_complete(file="out_c2_006.txt",alpha=0.0025, EMVC=FALSE, N = 1)

source('Msigdbc4_complete.r')
# output_emvc<-Msigdbc4_complete(EMVC=TRUE)
output_rtmtl<-Msigdbc4_complete(file="out_c4_logistic.txt",alpha=0.6, EMVC=FALSE) 