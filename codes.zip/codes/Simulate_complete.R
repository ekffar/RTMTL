Simulate_complete <- function(file="out.txt", alpha=0.1, EMVC=FALSE){
  # file = "out.txt" is the name of input file,   alpha is a threshold 
  library("EMVC")
  library("pROC")
  library("limma")
  library("irr")

  load('simulated_data.RData')
  
  o <- array(0, dim=c(20,300,25))
  T <- array(0,dim=c(20,300,25))
  
  if(EMVC == TRUE){
    for(i in 1:25){
      o[,,i] <- EMVC(data[,,i], annotation, bootstrap.iter=50, k.range=5:15, clust.method="hclust", 
                     hclust.method="average", hclust.cor.method="spearman")
      T[,,i] <- filterAnnotations(o[,,i], alpha)
    }
  }else{
    out <- read.table(file,header=FALSE)
    out <- as.matrix(out)
    for(i in 1 : 25){
      o[,,i] <- out[,(300*i-299):(300*i)]
    }
    
    for(i in 1 : 25){
      T[,,i] <- filterAnnotations(o[,,i], alpha)  # alpha is threshold that need to tune
    }
  }
  
  # compute auc value
  auc <- rep(0,25)
  for(j in 1:25){
    x <- o[,,j]
    y <- c()
    z <- c()
    for(i in 1:20){
      index <- which(annotation[i,]!=0)
      z <- c(z,x[i,index])
      y <- c(y,validity[i,index])
    }
    roc <- roc(y,z)
    auc[j] <- roc$auc
  }
  
  # compute FDR values using unoptimized annotations
  unfdr <- matrix(0,20,25)
  design <- cbind(Intercept=1,Group=c(rep(0,50),rep(1,50)))
  for(j in 1:25){
    b <- c()
    c <- vector("list",20)
    for(i in 1:20){
      c[[i]] <- which(annotation[i,]==1)
    }
    b <- camera(t(data[,,j]), c, design,sort=FALSE)
    unfdr[,j] <- b$FDR
  }
  # compute FDR values using optimized annotations
  fdr <- matrix(0,20,25)
  design <- cbind(Intercept=1,Group=c(rep(0,50),rep(1,50)))
  for(j in 1:25){
    b <- c()
    c <- vector("list",20)
    for(i in 1:20){
      c[[i]] <- which(T[i,,j]==1)
    }
    b <- camera(t(data[,,j]), c, design,sort=FALSE)
    fdr[,j] <- b$FDR
  }

  # compute Kendall' coefficient
  kc <- kendall(fdr, FALSE)
  kc <- kc$value
  kc_un <- kendall(unfdr, FALSE)
  kc_un <- kc_un$value
  
  output <- list(o = o, T=T, auc = auc, unfdr= unfdr, fdr=fdr, kc=kc, kc_un=kc_un)
  return(output) 
} 
