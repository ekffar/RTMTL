% experiment on simulated dataset
clear;
addpath(genpath('MALSAR1.1'));

rzhi = 0.115;
opts.init = 0;
opts.tol =  10e-10;
opts.max_iter = 500;
task = 20;

load simulated_data.mat;
result = zeros(task, 300*25);
for j = 1:25
    data_in = data(:,:,j);
    out = zeros(task, 300);
  
    X = cell(task ,1);
    Y = cell(task ,1);
    for i = 1: task
        X{i} = data_in';
        yy = annotation(i,:)';
        yy(yy == 0 ) = -1;
        Y{i} = yy;
    end
    rho1 = rzhi;
    [W, C, fzhi] = Logistic_Trace(X, Y, rho1, opts);

    for i = 1 : task
        sigma = @(x) 1 ./(1 + exp(-W(:, i)'*x - C(i)));
        si = sigma(data_in);
        out(i,:) = si;
        onevector = si(Y{i} ==1);
        zerovector = si(Y{i} == -1);
        one = repmat(onevector', 1, length(zerovector) );
        zero = repmat( zerovector, length(onevector), 1 );
        k = one - zero;
        auc(i) = length( find(k > 0) ) / (length(onevector) * length(zerovector) ) ;
    end
    out = out .* annotation(1:task, :);
    result(:, 300*j-300+1: 300*j) = out;
end
save('out.txt', 'result','-ASCII');