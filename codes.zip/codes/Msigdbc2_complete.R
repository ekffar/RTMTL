Msigdbc2_complete <- function(file, alpha=0.1, N=1, EMVC=FALSE){
  # out is the name of input file,   alpha is a threshold 
  # EMVC default value is FALSE. EMVC == TRUE, then this function compute the experiment in the paper
  # otherwise compute the result using our own method
  # N is used when computing Kendall's coefficient. 
  library("EMVC")
  library("pROC")
  library("limma")
  library("irr")
  load('MSigDBc2_data_express_annotation_validity.RData')
  
  if(EMVC == TRUE){
    o <- EMVC(express, annotation, bootstrap.iter=50, k.range=3:15, clust.method="kmeans", 
              kmeans.nstart=1, kmeans.iter.max=10)
    T <- filterAnnotations(o, alpha)
  }else{
    out <- read.table(file,header=FALSE)
    o <- as.matrix(out)
    T <- filterAnnotations(o, alpha)
  }
  
    # compute auc value
    x <- o
    y <- c()
    z <- c()
    for(i in 1:301){
      index <- which(annotation[i,]!=0)
      z <- c(z,x[i,index])
      y <- c(y,validity[i,index])
    }
    auc <- roc(y,z)
    auc <- auc$auc
    
    # compute FDR values using unoptimized annotations
    unfdr <- c()
    design <- cbind(Intercept=1,Group=c(rep(0,33),rep(1,17)))
    c <- vector("list",301)
    for(i in 1:301){
      c[[i]] <- which(annotation[i,]==1)
    }
    b <- camera(t(express), c, design, sort=FALSE)
    unfdr <- b$FDR
    # compute FDR values using optimized annotations
    fdr <- c()
    design <- cbind(Intercept=1,Group=c(rep(0,33),rep(1,17)))
    c <- vector("list",301)
    for(i in 1:301){
      c[[i]] <- which(T[i,]==1)
    }
    b <- camera(t(express), c, design, sort=FALSE)
    fdr <- b$FDR
    
    ### compute Kendall's coefficient
    load('data.RData')
    kc <- array(0, dim=c(N))
    kc_un <- array(0, dim=c(N))
    for(ijk in 1 : N){
      # create multiple datasets
#       data <- array(0,dim=c(50,ncol(express),20))
#       for(i in 1:20){
#         data[,,i] <- rbind(express[sample(1:33,33,replace=TRUE),], express[sample(34:50,17,replace=TRUE),])
#         sd <- sqrt(apply(data[,,i],2,var))
#         mu <- apply(data[,,i],2,mean)
#         mu <- t(matrix(rep(mu,50),ncol(data[,,i])))
#         sd <- t(matrix(rep(sd,50),ncol(data[,,i])))
#         data[,,i] <- (data[,,i]-mu)/sd
#       }
      # Kendall��s W using unoptimized annotation
      fdr_k <- matrix(0,301,20)
      design <- cbind(Intercept=1,Group=c(rep(0,33),rep(1,17)))
      for(j in 1:20){
        c <- vector("list",301)
        for(i in 1:301){
          c[[i]] <- which(annotation[i,]==1)
        }
        b <- camera(t(data[,,j]), c, design,sort=FALSE)
        fdr_k[,j] <- b$PValue
      }
      ijk_un <- kendall(fdr_k,TRUE)
      kc_un[ijk] <- ijk_un$value
      
      # Kendall��s W using optimized annotation
      fdr_k <- matrix(0,301,20)
      design <- cbind(Intercept=1,Group=c(rep(0,33),rep(1,17)))
      for(j in 1:20){
        c <- vector("list",301)
        for(i in 1:301){
          c[[i]] <- which(T[i,]==1)
        }
        b <- camera(t(data[,,j]), c, design,sort=FALSE)
        fdr_k[,j] <- b$PValue
      }
      ijk_o <- kendall(fdr_k,TRUE)
      kc[ijk] <- ijk_o$value
    }
#   save(data, file = 'data.RData')
  output <- list(o=o, T=T,auc = auc, unfdr= unfdr, fdr=fdr, kc=kc, kc_un=kc_un)
  return(output)
}