Msigdbc4_complete <- function(file, alpha=0.15, N=1, EMVC=FALSE){
  # out is the name of input file,   alpha is a threshold 
  # original default value is FALSE. original == TRUE, then this function compute the experiment in the paper
  # otherwise compute the result using our own method
  # N is used when computing Kendall's coefficient. 
  library("EMVC")
  library("pROC")
  library("limma")
  library("irr")
  load('MSigDBc4_data_express_annotation_validity.RData')
  
  if(EMVC==FALSE){
    out <- read.table(file,header=FALSE)
    o <- as.matrix(out)
    #o <- o[1:100,]
    T <- filterAnnotations(o, alpha)
  }else{
    o <- EMVC(express, annotation, bootstrap.iter=50, k.range=3:15, clust.method="hclust", 
              hclust.method="average", hclust.cor.method="spearman")
    T <- filterAnnotations(o, alpha)
  }
  ### compute auc value ###
  x <- o
  y <- c()
  z <- c()
  for(i in 1:nrow(o)){
    index <- which(annotation[i,]!=0)
    z <- c(z,x[i,index])
    y <- c(y,validity[i,index])
  }
  auc <- roc(y,z)
  auc <- auc$auc
  
  # fdr for unoptimal annotation matrix
  design <- cbind(Intercept=1,Group=c(rep(0,24),rep(1,24)))
  c <- vector("list",nrow(o))
  for(i in 1:nrow(o)){
    c[[i]] <- which(annotation[i,]==1)
  }
  b <- camera(t(express), c, design)
  unfdr <- b$FDR
  # fdr for optimal annotation matrix
  design <- cbind(Intercept=1,Group=c(rep(0,24),rep(1,24)))
  c <- vector("list",nrow(o))
  for(i in 1:nrow(o)){
    c[[i]] <- which(T[i,]==1)
  }
  b <- camera(t(express), c, design, sort=FALSE)
  fdr <- b$FDR
  
  ######## compute Kendall's coefficient ##########
  load('KC_data_C4.RData')
  kc <- array(0, dim=c(N))
  kc_un <- array(0, dim=c(N))
  for(ijk in 1 : N){
#     data <- array(0,dim=c(48,ncol(express),20))
#     for(i in 1:20){
#       data[,,i] <- rbind(express[sample(1:24,24,replace=TRUE),],express[sample(25:48,24,replace=TRUE),])
#       sd <- sqrt(apply(data[,,i],2,var))
#       mu <- apply(data[,,i],2,mean)
#       mu <- t(matrix(rep(mu,48),ncol(data[,,i])))
#       sd <- t(matrix(rep(sd,48),ncol(data[,,i])))
#       data[,,i] <- (data[,,i]-mu)/sd
#     }
    
    fdr_k <- matrix(0,nrow(o),20)
    design <- cbind(Intercept=1,Group=c(rep(0,24),rep(1,24)))
    
    for(j in 1:20){
      c <- vector("list",nrow(o))
      for(i in 1:nrow(o)){
        c[[i]] <- which(annotation[i,]==1)
      }
      b <- camera(t(data[,,j]), c, design, sort=FALSE)
      fdr_k[,j] <- b$PValue
    }
    ijk_un <- kendall(fdr_k,TRUE)
    kc_un[ijk] <- ijk_un$value
    
    # compute kendall's W using optimized annotation
    fdr_k <- matrix(0,nrow(o),20)
    design <- cbind(Intercept=1,Group=c(rep(0,24),rep(1,24)))
    
    for(j in 1:20){
      c <- vector("list",nrow(o))
      for(i in 1:nrow(o)){
        c[[i]] <- which(T[i,]==1)
      }
      b <- camera(t(data[,,j]), c, design, sort=FALSE)
      fdr_k[,j] <- b$PValue
    }
    ijk_o <- kendall(fdr_k,TRUE)
    kc[ijk] <- ijk_o$value
  }
#   save(data, file = 'KC_data_C4.RData')
  output <- list(o=o,T = T, auc = auc, unfdr= unfdr, fdr=fdr, kc=kc, kc_un=kc_un, data = data)
  return(output)
}

