% experiments on datac2 and datac4
clear;
addpath(genpath('MALSAR1.1'));
data = 'datac2'                   % datac2 or datac4
option = 'output';        % output     cv_testauc   cv_trainauc
weight = 'no'
wzhi = 400;
% task = 297;
task = 301;

rzhi = 0.0;
opts.init = 0;
opts.tol =  10e-10;
opts.max_iter = 300;

%% expriments for datac2
if strcmp(data,'datac2')
    if strcmp(option, 'output')
        
        load datac2.mat
        out = zeros(task, size(datac2,2));
        X = cell(task ,1);
        Y = cell(task ,1);
        for i = 1: task
            X{i} = datac2';
            yy = annotationc2(i,:)';
            yy(yy == 0 ) = -1;
            Y{i} = yy;
        end
        rho1 = rzhi;
        [W, C, fzhi] = Logistic_Trace(X, Y, rho1, opts);
        for i = 1 : task
            sigma = @(x) 1 ./(1 + exp(-W(:, i)'*x - C(i)));
            si = sigma(datac2);
            out(i,:) = si;
            onevector = si(Y{i} ==1);
            zerovector = si(Y{i} == -1);
            one = repmat(onevector', 1, length(zerovector) );
            zero = repmat( zerovector, length(onevector), 1 );
            k = one - zero;
            auc(i) = length( find(k > 0) ) / (length(onevector) * length(zerovector) ) ;
        end
        out = out .* annotationc2(1:task, :);
        save('out_c2.txt', 'out','-ASCII');
        
    elseif  strcmp(option, 'cv_testauc')
        
        load multitask_paixu.mat;
        load datac2.mat;

        auc = zeros(task,200, length(rzhi));
        mo = zeros(200,task);
        for rh = 1 : length(rzhi)
            
            for j = 1: size(auc, 2)
                task = 10;
                X = cell(task ,1);
                Y = cell(task ,1);
                for i = 1: task
                    sets = i;
                    dsize = size(datac2);
                    index = find(annotationc2(sets, :) > 0 );
                    data = datac2;
                    annotation = annotationc2;
                    data = [ones(1,size(data,2)); data];
                    ba = annotation(:, index);
                    bd = data(:, index);
                    annotation(:, index) = [];
                    data(:, index) = [];
                    
                    traina = [ annotation(:, paixu{sets,j}(1: round(2/3* (dsize(2) - length(index))) ))  ba(:, bpaixu{sets,j}(1: round(2/3* length(index))))];
                    traind = [ data(:, paixu{sets,j}( 1: round( 2/3 * (dsize(2) - length(index) ) ) ) )  bd(:, bpaixu{sets,j}( 1: round( 2/3 * length(index) ) ) ) ];
                    if strcmp(weight, 'yes')
                        wtraina = ba(:, bpaixu{sets,j}(1: round(2/3* length(index))));
                        wtraind = bd(:, bpaixu{sets,j}( 1: round( 2/3 * length(index) ) ) ) ;
                        traina = [traina wtraina(:, randi(size(wtraina,2), 1, wzhi*size(wtraina, 2) ) ) ];
                        traind = [traind wtraind(:, randi(size(wtraind,2), 1, wzhi* size(wtraind,2) ) ) ];
                    end
                    X{i} = traind(2:end, :)';
                    
                    yy = traina(sets,:)';
                    yy(yy == 0 ) = -1;
                    
                    Y{i} = yy;
                end
                rho1 = rzhi(rh);
                [W, C, ~] = Logistic_Trace(X, Y, rho1, opts);        
                
                for i = 1 : 10
                    sets = i;
                    dsize = size(datac2);
                    index = find(annotationc2(sets, :) > 0 );
                    data = datac2;
                    annotation = annotationc2;
                    data = [ones(1,size(data,2)); data];
                    ba = annotation(:, index);
                    bd = data(:, index);
                    annotation(:, index) = [];
                    data(:, index) = [];
                    
                    testa =  [ annotation( :, paixu{sets,j}(round(2/3 * (dsize(2) - length(index) )) +1 : end ) )  ba(:, bpaixu{sets,j}( round(2/3* length(index) ) +1 : end) ) ];
                    testd = [ data(:, paixu{sets,j}(round( 2/3 * (dsize(2) - length(index) )) +1 : end) )  bd(:, bpaixu{sets,j}(round( 2/3 * length(index) ) +1 : end ) ) ];
                    sigma = @(x) 1 ./(1 + exp(-W(:, i)'*x - C(i)));
                    si = sigma(testd(2:end, :) );
                    onevector = si(testa(i, :) ==1);
                    zerovector = si(testa(i, :) == 0);
                    one = repmat(onevector', 1, length(zerovector) );
                    zero = repmat( zerovector, length(onevector), 1 );
                    k = one - zero;
                    auc(i,j, rh) = length( find(k > 0) ) / (length(onevector) * length(zerovector) ) ;
                    
                end
                j
                %             auc(: ,j, rh)
                %             sum(auc(1,:, rh)) / j
%                 save auc auc;
            end
        end
    elseif strcmp(option, 'cv_trainauc')
        
        load multitask_paixu.mat;
        load datac2.mat;
        
        auc = zeros(task,200, length(rzhi));
        mo = zeros(200,task);
        for rh = 1 : length(rzhi)
            
            for j = 1: size(auc, 2)
                
                X = cell(task ,1);
                Y = cell(task ,1);
                for i = 1: task
                    sets = i;
                    dsize = size(datac2);
                    index = find(annotationc2(sets, :) > 0 );
                    data = datac2;
                    annotation = annotationc2;
                    data = [ones(1,size(data,2)); data];
                    ba = annotation(:, index);
                    bd = data(:, index);
                    annotation(:, index) = [];
                    data(:, index) = [];
                    
                    traina = [ annotation(:, paixu{sets,j}(1: round(2/3* (dsize(2) - length(index))) ))  ba(:, bpaixu{sets,j}(1: round(2/3* length(index))))];
                    traind = [ data(:, paixu{sets,j}( 1: round( 2/3 * (dsize(2) - length(index) ) ) ) )  bd(:, bpaixu{sets,j}( 1: round( 2/3 * length(index) ) ) ) ];
                    if strcmp(weight, 'yes')
                        wtraina = ba(:, bpaixu{sets,j}(1: round(2/3* length(index))));
                        wtraind = bd(:, bpaixu{sets,j}( 1: round( 2/3 * length(index) ) ) ) ;
                        traina = [traina wtraina(:, randi(size(wtraina,2), 1, wzhi*size(wtraina, 2) ) ) ];
                        traind = [traind wtraind(:, randi(size(wtraind,2), 1, wzhi* size(wtraind,2) ) ) ];
                    end
                    X{i} = traind(2:end, :)';
                    
                    yy = traina(sets,:)';
                    yy(yy == 0 ) = -1;
                    
                    Y{i} = yy;
                end
                rho1 = rzhi(rh);
                [W, C, ~] = Logistic_Trace(X, Y, rho1, opts);
                
                for i = 1 : task
                    sigma = @(x) 1 ./(1 + exp(-W(:, i)'*x - C(i)));
                    si = sigma( X{i}' );
                    
                    onevector = si(Y{i} ==1);
                    zerovector = si(Y{i} == -1);
                    one = repmat(onevector', 1, length(zerovector) );
                    zero = repmat( zerovector, length(onevector), 1 );
                    k = one - zero;
                    auc(i,j, rh) = length( find(k > 0) ) / (length(onevector) * length(zerovector) ) ;
                    
                end
                j
                %             auc(4 ,j, rh)
                sum(auc(:,: , rh),2) / j
                
            end
        end
    else
        disp('this exceed the option');
    end
    
    
else
    
    %% train datac4 
    if strcmp(option, 'output')
        
        load datac4.mat
        out = zeros(task, size(datac4,2));
        X = cell(task ,1);
        Y = cell(task ,1);
        for i = 1: task
            X{i} = datac4';
            yy = annotationc4(i,:)';
            yy(yy == 0 ) = -1;
            Y{i} = yy;
        end
        rho1 = rzhi;
        [W, C, fzhi] = Logistic_Trace(X, Y, rho1, opts);

        for i = 1 : task
            sigma = @(x) 1 ./(1 + exp(-W(:, i)'*x - C(i)));
            si = sigma(datac4);
            out(i,:) = si;
            onevector = si(Y{i} ==1);
            zerovector = si(Y{i} == -1);
            one = repmat(onevector', 1, length(zerovector) );
            zero = repmat( zerovector, length(onevector), 1 );
            k = one - zero;
            auc(i) = length( find(k > 0) ) / (length(onevector) * length(zerovector) ) ;
        end
        out = out .* annotationc4(1:task, :);
        save('out_c4.txt', 'out','-ASCII');
        
    elseif  strcmp(option, 'cv_testauc')     
        load c4multitask_paixu.mat;
        load datac4.mat;
        
        auc = zeros(task,200, length(rzhi));
        mo = zeros(200,task);
        for rh = 1 : length(rzhi)
            
            for j = 1: size(auc, 2)
                task = 10;
                X = cell(task ,1);
                Y = cell(task ,1);
                for i = 1: task
                    sets = i;
                    dsize = size(datac4);
                    index = find(annotationc4(sets, :) > 0 );
                    data = datac4;
                    annotation = annotationc4;
                    data = [ones(1,size(data,2)); data];
                    ba = annotation(:, index);
                    bd = data(:, index);
                    annotation(:, index) = [];
                    data(:, index) = [];
                    
                    traina = [ annotation(:, paixu{sets,j}(1: round(2/3* (dsize(2) - length(index))) ))  ba(:, bpaixu{sets,j}(1: round(2/3* length(index))))];
                    traind = [ data(:, paixu{sets,j}( 1: round( 2/3 * (dsize(2) - length(index) ) ) ) )  bd(:, bpaixu{sets,j}( 1: round( 2/3 * length(index) ) ) ) ];
                    if strcmp(weight, 'yes')
                        wtraina = ba(:, bpaixu{sets,j}(1: round(2/3* length(index))));
                        wtraind = bd(:, bpaixu{sets,j}( 1: round( 2/3 * length(index) ) ) ) ;
                        traina = [traina wtraina(:, randi(size(wtraina,2), 1, wzhi*size(wtraina, 2) ) ) ];
                        traind = [traind wtraind(:, randi(size(wtraind,2), 1, wzhi* size(wtraind,2) ) ) ];
                    end
                    X{i} = traind(2:end, :)';
                    
                    yy = traina(sets,:)';
                    yy(yy == 0 ) = -1;
                    
                    Y{i} = yy;
                end
                rho1 = rzhi(rh);
                [W, C, ~] = Logistic_Trace(X, Y, rho1, opts);

                for i = 1 : 10
                    sets = i;
                    dsize = size(datac4);
                    index = find(annotationc4(sets, :) > 0 );
                    data = datac4;
                    annotation = annotationc4;
                    data = [ones(1,size(data,2)); data];
                    ba = annotation(:, index);
                    bd = data(:, index);
                    annotation(:, index) = [];
                    data(:, index) = [];
                    
                    testa =  [ annotation( :, paixu{sets,j}(round(2/3 * (dsize(2) - length(index) )) +1 : end ) )  ba(:, bpaixu{sets,j}( round(2/3* length(index) ) +1 : end) ) ];
                    testd = [ data(:, paixu{sets,j}(round( 2/3 * (dsize(2) - length(index) )) +1 : end) )  bd(:, bpaixu{sets,j}(round( 2/3 * length(index) ) +1 : end ) ) ];
                    sigma = @(x) 1 ./(1 + exp(-W(:, i)'*x - C(i)));
                    si = sigma(testd(2:end, :) );
                    onevector = si(testa(i, :) ==1);
                    zerovector = si(testa(i, :) == 0);
                    one = repmat(onevector', 1, length(zerovector) );
                    zero = repmat( zerovector, length(onevector), 1 );
                    k = one - zero;
                    auc(i,j, rh) = length( find(k > 0) ) / (length(onevector) * length(zerovector) ) ;
                    
                end
                j
                %             auc(: ,j, rh)
                            sum(auc(:,:, rh), 2) / j  
            end
        end
    elseif strcmp(option, 'cv_trainauc')
        
        load c4multitask_paixu.mat;
        load datac4.mat; 
        auc = zeros(task,200, length(rzhi));
        mo = zeros(200,task);
        for rh = 1 : length(rzhi)
            
            for j = 1: size(auc, 2)
                
                X = cell(task ,1);
                Y = cell(task ,1);
                for i = 1: task
                    sets = i;
                    dsize = size(datac4);
                    index = find(annotationc4(sets, :) > 0 );
                    data = datac4;
                    annotation = annotationc4;
                    data = [ones(1,size(data,2)); data];
                    ba = annotation(:, index);
                    bd = data(:, index);
                    annotation(:, index) = [];
                    data(:, index) = [];
                    
                    traina = [ annotation(:, paixu{sets,j}(1: round(2/3* (dsize(2) - length(index))) ))  ba(:, bpaixu{sets,j}(1: round(2/3* length(index))))];
                    traind = [ data(:, paixu{sets,j}( 1: round( 2/3 * (dsize(2) - length(index) ) ) ) )  bd(:, bpaixu{sets,j}( 1: round( 2/3 * length(index) ) ) ) ];
                    if strcmp(weight, 'yes')
                        wtraina = ba(:, bpaixu{sets,j}(1: round(2/3* length(index))));
                        wtraind = bd(:, bpaixu{sets,j}( 1: round( 2/3 * length(index) ) ) ) ;
                        traina = [traina wtraina(:, randi(size(wtraina,2), 1, wzhi*size(wtraina, 2) ) ) ];
                        traind = [traind wtraind(:, randi(size(wtraind,2), 1, wzhi* size(wtraind,2) ) ) ];
                    end
                    X{i} = traind(2:end, :)';
                    
                    yy = traina(sets,:)';
                    yy(yy == 0 ) = -1;
                    
                    Y{i} = yy;
                end
                rho1 = rzhi(rh);
                [W, C, ~] = Logistic_Trace(X, Y, rho1, opts);
          
                for i = 1 : task
                    sigma = @(x) 1 ./(1 + exp(-W(:, i)'*x - C(i)));
                    si = sigma( X{i}' );
                    
                    onevector = si(Y{i} ==1);
                    zerovector = si(Y{i} == -1);
                    one = repmat(onevector', 1, length(zerovector) );
                    zero = repmat( zerovector, length(onevector), 1 );
                    k = one - zero;
                    auc(i,j, rh) = length( find(k > 0) ) / (length(onevector) * length(zerovector) ) ;
                    
                end
                j
                %             auc(4 ,j, rh)
                sum(auc(:,: , rh),2) / j                
            end
        end
    else
        disp('this exceed the option');
    end
end